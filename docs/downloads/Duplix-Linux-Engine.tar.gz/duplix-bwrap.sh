#!/bin/bash
# Duplix Linux Bubblewrap Isolated Sandbox Launcher
set -e
APP_BIN="$1"
PROFILE_ID="$2"
if [ -z "$APP_BIN" ] || [ -z "$PROFILE_ID" ]; then
    echo "Usage: duplix-bwrap.sh /usr/bin/app profile-id"
    exit 1
fi
SANDBOX_DIR="$HOME/.local/share/duplix/profiles/$PROFILE_ID"
mkdir -p "$SANDBOX_DIR"
echo "[Duplix] Launching $APP_BIN inside Bubblewrap container ($PROFILE_ID)..."
exec bwrap     --ro-bind / /     --dev /dev     --proc /proc     --bind "$SANDBOX_DIR" "$HOME"     --setenv HOME "$HOME"     "$APP_BIN" "${@:3}"
