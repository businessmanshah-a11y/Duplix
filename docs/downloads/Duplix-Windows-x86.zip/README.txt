Duplix Windows Engine v1.4.0 (32-bit (x86 Legacy))
=====================================================
Target Architecture: x86
Default App Directory: C:\Program Files (x86)

Features:
- Complete session isolation for Electron, Chromium, VS Code, Slack, Discord
- Custom Taskbar badges and isolated Start Menu shortcuts
- Zero-overhead isolated user data directories
