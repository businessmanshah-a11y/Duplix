Duplix Windows Engine v1.4.0 (Phase 2 Preview)
================================================
Compatible with Windows 10 & 11 (64-bit, 32-bit, ARM64)

Features:
- Complete session isolation for Electron, Chromium, VS Code, Slack, Discord
- Custom Taskbar badges and isolated Start Menu shortcuts
- Zero-overhead isolated user data directories

Quick Start:
1. Run PowerShell as Administrator or user
2. Execute:
   .\DuplixLauncher.ps1 -AppPath "C:\Program Files\Google\Chrome\Application\chrome.exe" -ProfileId "Work-Chrome"
