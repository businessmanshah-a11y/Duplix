@echo off
REM Duplix Windows Fast Batch Launcher
set APP_PATH=%~1
set PROFILE_ID=%~2
if "%APP_PATH%"=="" (
    echo Usage: DuplixLauncher.cmd "C:\Path\To\App.exe" "Profile-1"
    exit /b 1
)
set DATA_DIR=%LOCALAPPDATA%\Duplix\Profiles\%PROFILE_ID%\Data
if not exist "%DATA_DIR%" mkdir "%DATA_DIR%"
echo [Duplix] Launching %APP_PATH% in isolated profile: %PROFILE_ID%
start "" "%APP_PATH%" --user-data-dir="%DATA_DIR%"
