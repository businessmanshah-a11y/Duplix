@echo off
title Duplix Windows Setup v1.4.0
color 0b
echo ========================================================
echo               Duplix Windows Setup
echo ========================================================
echo.
echo Installing Duplix Multi-Instance Engine for Windows...
set INSTALL_DIR=%LOCALAPPDATA%\Duplix
mkdir "%INSTALL_DIR%in" 2>nul
mkdir "%INSTALL_DIR%\Profiles" 2>nul
copy /y "%~dp0DuplixLauncher.cmd" "%INSTALL_DIR%in\duplix.cmd" >nul
copy /y "%~dp0DuplixLauncher.ps1" "%INSTALL_DIR%in\duplix.ps1" >nul

echo [SUCCESS] Duplix is installed!
echo Location: %INSTALL_DIR%
echo You can run: duplix.cmd "C:\Path\To\App.exe" Profile-1
echo.
pause
