Duplix Windows Engine v1.4.0 (ARM64 (Qualcomm Snapdragon / Surface))
=====================================================
Target Architecture: ARM64
Default App Directory: C:\Program Files

Features:
- Complete session isolation for Electron, Chromium, VS Code, Slack, Discord
- Custom Taskbar badges and isolated Start Menu shortcuts
- Zero-overhead isolated user data directories
