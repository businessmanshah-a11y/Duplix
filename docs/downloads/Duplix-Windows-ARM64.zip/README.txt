Duplix for Windows (v1.4.0)
===========================
Double-click Install-Duplix.cmd to install.
