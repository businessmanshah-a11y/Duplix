param(
    [Parameter(Mandatory=$true)][string]$AppPath,
    [Parameter(Mandatory=$true)][string]$ProfileId,
    [string]$ExtraArgs = ""
)
$DataDir = "$env:LOCALAPPDATA\Duplix\Profiles\$ProfileId\Data"
if (!(Test-Path $DataDir)) {
    New-Item -ItemType Directory -Force -Path $DataDir | Out-Null
}
Write-Host "[Duplix] Launching $AppPath in profile: $ProfileId" -ForegroundColor Cyan
Start-Process -FilePath $AppPath -ArgumentList "--user-data-dir="$DataDir" $ExtraArgs"
