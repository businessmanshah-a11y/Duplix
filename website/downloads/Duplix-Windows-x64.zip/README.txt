Duplix Windows Engine v1.4.0 (64-bit (x64))
=====================================================
Target Architecture: x64
Default App Directory: C:\Program Files

Features:
- Complete session isolation for Electron, Chromium, VS Code, Slack, Discord
- Custom Taskbar badges and isolated Start Menu shortcuts
- Zero-overhead isolated user data directories
